title: ARTS Week 2
date: '2019-07-14 15:38:10'
updated: '2019-07-14 15:38:57'
tags: [ARTS]
permalink: /articles/2019/07/14/1563089890038.html
---
上周的 ARTS 写的比较仓促，其实只能算是个凑数文，因为确实是时间不够写，但是 ART 都做完了，S 就草草写了，理论上这周发布这篇的时候会将上周的 S 写成一篇完整的 Blog。

## Algorithm

> ## 两两交换链表中的节点
> 给定一个链表，两两交换其中相邻的节点，并返回交换后的链表。

> 你不能只是单纯的改变节点内部的值，而是需要实际的进行节点交换。

 
> 示例:

> ```
> 给定 1->2->3->4, 你应该返回 2->1->4->3.
> ```


```python3
# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, x):
#         self.val = x
#         self.next = None

class Solution:
    def swapPairs(self, head: ListNode) -> ListNode:
        if not head or not head.next:
            return head
        a = head
        b = head.next
        a.next = self.swapPairs(b.next)
        b.next = a
        return b
```
## Review: AWS Lambda

这周看了个讲 AWS lambda 的冷启动热启动时间的文章。

### 什么是 AWS Lambda

这是基于 Serverless 诞生的 Faas 技术，就是托管的从 Saas 的服务简化成了一个函数，讲函数托管到服务商，一旦产生调用，服务放会调用函数并且返回结果。

优点在于：
- 不需要管理机器
- 并发毫秒级扩容
- 更新部署速度快

缺点在于：
- 掌控权在服务方
- 单次启动存在时间限制
- 24小时运转费用高
- 不能进行非常复杂的计算

### 冷启动和热启动
冷启动是 lambda 的初始化创建的时候，第一次创建 Function 实例。
文中所说应用的初始化时间和应用大小正相关。这也是我在上面所说 lambda 不能承载过于复杂的计算。简单应用的平均时间在 800ms 左右。

热启动是 lamdba 在第一次创建之后，还会继续处理一些请求，这时候并不会新创建一个 Function 实例，所以响应时间就在 50ms 左右。

但实际上考虑到性能 800ms 和 50ms 在高并发场景都不太能接受，所以要在高并发场景下使用还需要进行大面积的改造工作。
据说阿里自己打造的 lambda 可以做到毫秒级的启动。

### 使用场景

那么 lambda 适合什么样的场景下使用呢

1. 计算量小
2. 调用频率低或异常集中
3. 可以任意横向扩展

## Tip

在讨论需求时，要对业务背景和业务目标有一定的了解，同时需要了解之后的业务方向，这样才可能做到兼容未来的设计，并且不会出现特别过度设计的情况。

但是往往产品对技术了解不深，不知道需求会有多大的实现难度，我们还是需要用尽可能简单易懂的方式将给产品听，产品与测试我们的客户，让客户知道我们技术选型的理由，并且提高他们的技术理解，我认为也是优秀程序员的职责。纯技术研发例外

## Share

[Thoughtworks 一月](https://eindex.me/articles/2019/07/14/1563089826559.html)


