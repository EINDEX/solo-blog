title: sshfs 网络磁盘映射到本地
date: '2019-05-09 21:17:01'
updated: '2019-05-09 21:17:01'
tags: [linux]
permalink: /articles/2019/05/09/1557407820996.html
---
## 缘起

老友安利给我个新玩意，叫做 sshfs，跟我讲呀，这个东西方便啊，直接把网络上的磁盘映射到本地，部署项目再也不用 git 远程同步。
<!-- more -->
##简介

> **SSHFS**（**SSH Filesystem**）是一种通过普通[ssh](https://zh.wikipedia.org/wiki/Ssh)连接来[挂载](https://zh.wikipedia.org/w/index.php?title=%E6%8C%82%E8%BD%BD&action=edit&redlink=1)和与远程[服务器](https://zh.wikipedia.org/wiki/%E6%9C%8D%E5%8A%A1%E5%99%A8)或[工作站](https://zh.wikipedia.org/wiki/%E5%B7%A5%E4%BD%9C%E7%AB%99)上的[目录](https://zh.wikipedia.org/wiki/%E7%9B%AE%E5%BD%95_(%E6%96%87%E4%BB%B6%E7%B3%BB%E7%BB%9F))和[文件](https://zh.wikipedia.org/wiki/%E9%9B%BB%E8%85%A6%E6%AA%94%E6%A1%88)交互的[文件系统](https://zh.wikipedia.org/wiki/%E6%96%87%E4%BB%B6%E7%B3%BB%E7%BB%9F)[客户端](https://zh.wikipedia.org/wiki/%E5%AE%A2%E6%88%B7%E7%AB%AF)。[[1\]](https://zh.wikipedia.org/wiki/SSHFS#cite_note-SSHFS_OpenBSD_port-1)该种客户端通过[SSH文件传输协议](https://zh.wikipedia.org/wiki/SSH%E6%96%87%E4%BB%B6%E4%BC%A0%E8%BE%93%E5%8D%8F%E8%AE%AE)（SFTP）与远程文件系统交互，[[2\]](https://zh.wikipedia.org/wiki/SSHFS#cite_note-SSHFS_security-2)这是一种通过任何可靠[数据流](https://zh.wikipedia.org/w/index.php?title=%E6%95%B0%E6%8D%AE%E6%B5%81&action=edit&redlink=1)提供[文件访问](https://zh.wikipedia.org/wiki/%E6%96%87%E4%BB%B6%E8%AE%BF%E9%97%AE)、[文件传输](https://zh.wikipedia.org/w/index.php?title=%E6%96%87%E4%BB%B6%E4%BC%A0%E8%BE%93&action=edit&redlink=1)和[文件管理](https://zh.wikipedia.org/wiki/%E6%96%87%E4%BB%B6%E7%AE%A1%E7%90%86%E5%99%A8)功能的网络协议，它在设计上是[Secure Shell](https://zh.wikipedia.org/wiki/Secure_Shell)（SSH）协议2.0版的一个扩展。
>
> —— 摘自 [《SSHFS》](https://zh.wikipedia.org/wiki/SSHFS)

## 示例

```bash
# 官方示例
# sshfs [user@]host:[dic] mountpoint [options]
# 我的使用示例
sshfs eindex@pi:/host/eindex/ ~/pi
```

## 对比 FTP，AFP，NFS，SMB 有何优缺点

- FTP：SSHFS 是通过 SFTP 协议实现的，所以比 FTP 安全。
- AFP：SSHFS 只有有 SSH 端口就可以用，不需要安装 AFP 支持软件。
- NFS 和 SMB：都支持多用户，而 SSHFS 只支持单用户，相对来说在需求不高的时候，可以考虑 SSHFS。

## 综述

写了这么多，赶紧自己试试吧，可以让开发增速，还可以扩容各种贫穷版 MAC 的容量，是不是觉得很棒。