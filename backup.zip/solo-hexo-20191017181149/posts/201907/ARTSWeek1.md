title: ' ARTS Week 1'
date: '2019-07-08 00:20:44'
updated: '2019-07-08 00:20:44'
tags: [ARTS]
permalink: /articles/2019/07/08/1562516444327.html
---

## Algorithm
``` python
#
# @lc app=leetcode.cn id=111 lang=python3
#
# [111] 二叉树的最小深度
#
# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Solution:
    def minDepth(self, root: TreeNode) -> int:
        if not root:
            return 0
        def inner(node, depth = 1):
            if not node:
                return float('inf')
            if not node.left and not node.right:
                return depth
            return min(inner(node.left, depth+1), inner(node.right, depth+1))
        return inner(root)
        


```
## Review
https://medium.com/@fro_g/writing-a-simple-inverted-index-in-python-3c8bcb52169a

算是简单说明了一下倒排索引的原理。

文中提出的的一些小问题，实际上也可以通过同义词分析来解决。

## Tip

不要接到需求就写代码， 在遇见一个新系统的时候，先搞清楚需求和完善需求使用的相关技术再去写代码，不然时间都被坑没了。

## Share

最近对倒排索引较为感兴趣。

倒排索引的实际上就是词到内容id的一种散列表。
它的优点是可以快速查找文档位置。
缺点在于分词准确度策略难以选定。

使用倒排索引多半在搜索推荐服务中。
搜索故名思义 ，找到关键字出现的文档。
推荐则是通过用户行为提取标签，在用标签在现有的数据库中进行搜索。
