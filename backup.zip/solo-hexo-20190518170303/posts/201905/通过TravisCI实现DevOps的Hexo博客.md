title: 通过 Travis CI 实现 DevOps 的 Hexo 博客
date: '2019-05-09 21:18:15'
updated: '2019-05-09 21:18:15'
tags: [待分类]
permalink: /articles/2019/05/09/1557407895596.html
---
> ## DevOps
>  “DevOps”这个词是“development”和“operations”的组合。DevOps已经上升为一种文化，它促使开发人员（史蒂夫和安妮你们快回来）和其他运维人员协同工作。具体地说，在软件交付和部署的过程中沟通合作，为了能够更快速更可靠地发布质量更好的应用。
>  拥有DevOps文化的团队通常有一个共同的特征：熟练的多技能团队（史蒂夫，安妮和乔伊都在同一团队里），高水平的测试和自动发布（按持续交付的方式）以及团队成员之间共同的目标。
<!-- more -->
## 缘起
在了解到 `DevOps` 这个概念之后，我查询了一下相关知识发现， Github Pages 的 Hexo 的博客也可以通过 `Travis CI` 实现持续交付和持续部署，实现云上编辑，多处同步更新部署的功能。
想想真是酷毙了，那就开始行动。
## 准备工作
注册一个 [Travis CI](https://travis-ci.org/) 的账号，通过 Github 就可以登录啦。
如上图，在你的 repo 列表中开区对博客 ropo 的持续集成，然后进入设置页面。
打开以上3处开关即可。

## 实现
准备工作做好了，接下来就是持续构建博客了。
捋一捋思路，我们需要:
1. 将博客源代码上传至 博客 repo 的一个新分支中。
2. 配置 `.travis.yml` 让 Travis CI 可以识别 repo 并填写自动构建脚本。
3. (可选)分离主题，可以让博客分支下只有 hexo 模板和 source 文件
### 上传博客
**配置文件中的一些关键信息请勿上传**
使用一系列的 git 指令将博客源代码上传到github，我上传的分支就是 `blog-source` 分支。
### .travis.yml
在 git 目录下，创建 `.travis.yml` 。感谢 Next 主题的作者 iissnan 的思路以及配置文件。
```ymal
language: node_js
node_js: stable

# Travis-CI Caching
cache:
  directories:
    - node_modules

# S: Build Lifecycle
install:
  - npm install -g hexo-cli

before_script:
  - npm install
  # 这一步是添加主题，若你的主题在文件内可以去掉这行，或者自己配置主题
  - git submodule add  [github url] themes/next

script:
  - hexo clean
  - hexo g

after_script:
    #切换到 public
  - cd public
  - git init
  - git config user.name "EINDEX"
  - git config user.email "snowstarlbk@gmail.com"
  - git add .
  - git commit -m "Update Blog By Travis CI"
  #使用 Token@URL 的模式push内容
  #如果你不想使用 --force 的方式进行提交可以自行修改
  - git push --force --quiet "https://${GH_TOKEN}@${GH_REF}" master:master
  #对这个流程扩展可以实现对多个服务器的部署工作。
# E: Build LifeCycle

branches:
  only:
    - blog-source

env:
  global:
    - GH_REF: github.com/EINDEX/eindex.github.io.git
```
为了让 Travis CI 可以对 `master` 分支进行操作，我们需要为它申请一个 Token 。
Setting -> Personal access token 选择 Generate new token 。
将除 delete_repo 之外的权限都勾选上，确定生成之后便会得到 Token 。
** 此Token 只能看见一次 **

``
拿到 Token 将其配置到 Travis CI 对应项目的设置处，就是这里
以后配置的敏感信息都可以放在这里，比如说 ftp 同步的秘钥等。
对这个方法的扩展可以实现对多个服务器的部署，达到一处修改处处生效的效果。
### 分离主题
将你使用的主题的 github fork 到自己的账号里。
`git submodule add  [github url] themes/[path]`
在 ` .travis.yml` 添加上面这个语句，并把 path 配置到 `_config.yml` 的 theme 属性中即可实现同步。

## 以后如何写博客
- 在 github 上在线写
- 本地用 Git 提交
其他的事情都不需要你操心了，只用等待 Travis CI 来帮助你完成任务，是不是可以专注写作了呢？
- - -
## 参考
- [使用 Travis CI 自动更新 GitHub Pages](http://notes.iissnan.com/2016/publishing-github-pages-with-travis-ci/)


